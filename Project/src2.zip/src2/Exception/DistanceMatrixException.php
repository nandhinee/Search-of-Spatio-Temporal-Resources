<?php

/*
 * This file is part of the Ivory Google Map package.
 *
 * (c) Eric GELOEN <geloen.eric@gmail.com>
 *
 * For the full copyright and license information, please read the LICENSE
 * file that was distributed with this source code.
 */

//namespace Ivory\GoogleMap\Exception;

include_once ('src2\Services\DistanceMatrix\DistanceMatrixStatus.php');
include_once ('src2\Services\DistanceMatrix\DistanceMatrixElementStatus.php');
include_once ('src2\Exception\ServiceException.php');
//include_once ('src2\Services\Base\TravelMode.php');
//include_once ('src2\Services\Base\UnitSystem.php');

/**
 * DistanceMatrix exception.
 *
 * @author GeLo <geloen.eric@gmail.com>
 * @author Tyler Sommer <sommertm@gmail.com>
 */
class DistanceMatrixException extends ServiceException
{
    /**
     * Gets the "INVALID DISTANCE MATRIX REQUEST" exception.
     *
     * @return \Ivory\GoogleMap\Exception\DistanceMatrixException The "INVALID DISTANCE MATRIX REQUEST" exception.
     */
    public  function invalidDistanceMatrixRequest()
    {
        return "The directions request is not valid. It needs at least one origin and one destination.";
    }

    /**
     * Gets the "INVALID DISTANCE MATRIX REQUEST PARAMETERS" exception.
     *
     * @return \Ivory\GoogleMap\Exception\DistanceMatrixException The "INVALID DISTANCE MATRIX REQUEST PARAMETERS" exception.
     */
    public function invalidDistanceMatrixRequestParameters()
    {
        return (sprintf(
            '%s'.PHP_EOL.'%s'.PHP_EOL.'%s'.PHP_EOL.'%s',
            'The process arguments are invalid.',
            'The available prototypes are:',
            '- function process(array $origins, array $destinations)',
            '- function process(Ivory\GoogleMap\Services\DistanceMatrix\DistanceMatrixRequest $request)'
        ));
    }

    /**
     * Gets the "INVALID DISTANCE MATRIX REQUEST DESTINATION" exception.
     *
     * @return \Ivory\GoogleMap\Exception\DistanceMatrixException The "INVALID DISTANCE MATRIX REQUEST DESTINATION" exception.
     */
    public function invalidDistanceMatrixRequestDestination()
    {
        return (sprintf(
            '%s'.PHP_EOL.'%s'.PHP_EOL.'%s'.PHP_EOL.'%s'.PHP_EOL.'%s',
            'The destination adder arguments are invalid.',
            'The available prototypes are :',
            ' - function addDestination(string $destination)',
            ' - function addDestination(Ivory\GoogleMap\Base\Coordinate $destination)',
            ' - function addDestination(double $latitude, double $longitude, boolean $noWrap)'
        ));
    }

    /**
     * Gets the "INVALID DISTANCE MATRIX REQUEST ORIGIN" exception.
     *
     * @return \Ivory\GoogleMap\Exception\DistanceMatrixException The "INVALID DISTANCE MATRIX REQUEST ORIGIN" exception.
     */
    public function invalidDistanceMatrixRequestOrigin()
    {
        return (sprintf(
            '%s'.PHP_EOL.'%s'.PHP_EOL.'%s'.PHP_EOL.'%s'.PHP_EOL.'%s',
            'The origin adder arguments are invalid.',
            'The available prototypes are :',
            ' - function addOrigin(string $origin)',
            ' - function addOrigin(Ivory\GoogleMap\Base\Coordinate $origin)',
            ' - function addOrigin(double $latitude, double $longitude, boolean $noWrap)'
        ));
    }

    /**
     * Gets the "INVALID DISTANCE MATRIX REQUEST REGION" exception.
     *
     * @return \Ivory\GoogleMap\Exception\DistanceMatrixException The "INVALID DISTANCE MATRIX REQUEST REGION" exception.
     */
    public function invalidDistanceMatrixRequestRegion()
    {
        return "The distance matrix request region must be a string with two characters.";
    }

    /**
     * Gets the "INVALID DISTANCE MATRIX REQUEST LANGUAGE" exception.
     *
     * @return \Ivory\GoogleMap\Exception\DistanceMatrixException The "INVALID DISTANCE MATRIX REQUEST LANGUAGE" exception.
     */
    public function invalidDistanceMatrixRequestLanguage()
    {
        return "The distance matrix request language must be a string with two or five characters.";
    }

    /**
     * Gets the "INVALID DISTANCE MATRIX REQUEST SENSOR" exception.
     *
     * @return \Ivory\GoogleMap\Exception\DistanceMatrixException The "INVALID DISTANCE MATRIX REQUEST SENSOR" exception.
     */
    public function invalidDistanceMatrixRequestSensor()
    {
        return "The distance matrix request sensor flag must be a boolean value.";
    }

    /**
     * Gets the "INVALID DISTANCE MATRIX REQUEST TRAVEL MODE" exception.
     *
     * @return \Ivory\GoogleMap\Exception\DistanceMatrixException The "INVALID DISTANCE MATRIX REQUEST TRAVEL MODE" exception.
     */
    public function invalidDistanceMatrixRequestTravelMode()
    {
        $travelModes = array_diff(TravelMode::getTravelModes(), array(TravelMode::TRANSIT));

        return (sprintf(
            'The distance matrix request travel mode can only be : %s.',
            implode(', ', $travelModes)
        ));
    }

    /**
     * Gets the "INVALID DISTANCE MATRIX REQUEST UNIT SYSTEM" exception.
     *
     * @return \Ivory\GoogleMap\Exception\DistanceMatrixException The "INVALID DISTANCE MATRIX REQUEST UNIT SYSTEM" exception.
     */
    public function invalidDistanceMatrixRequestUnitSystem()
    {
        return (sprintf(
            'The distance matrix request unit system can only be : %s.',
            implode(', ', UnitSystem::getUnitSystems())
        ));
    }

    /**
     * Gets the "INVALID DISTANCE MATRIX REQUEST AVOID HIGHWAYS" exception.
     *
     * @return \Ivory\GoogleMap\Exception\DistanceMatrixException The "INVALID DISTANCE MATRIX REQUEST AVOID HIGHWAYS" exception.
     */
    public function invalidDistanceMatrixRequestAvoidHighways()
    {
        return "The distance matrix request avoid hightways flag must be a boolean value.";
    }

    /**
     * Gets the "INVALID DISTANCE MATRIX REQUEST AVOID TOLLS" exception.
     *
     * @return \Ivory\GoogleMap\Exception\DistanceMatrixException The "INVALID DISTANCE MATRIX REQUEST AVOID TOLLS" exception.
     */
    public function invalidDistanceMatrixRequestAvoidTolls()
    {
        return "The distance matrix request avoid tolls flag must be a boolean value.";
    }

    /**
     * Gets the "INVALID DISTANCE MATRIX RESPONSE STATUS" exception.
     *
     * @return \Ivory\GoogleMap\Exception\DistanceMatrixException The "INVALID DISTANCE MATRIX RESPONSE STATUS" exception.
     */
    public function invalidDistanceMatrixResponseStatus()
    {
        return (sprintf(
            'The distance matrix response status can only be : %s.',
            implode(', ', DistanceMatrixStatus::getDistanceMatrixStatus())
        ));
    }

    /**
     * Gets the "INVALID DISTANCE MATRIX RESPONSE ELEMENT STATUS" exception.
     *
     * @return \Ivory\GoogleMap\Exception\DistanceMatrixException The "INVALID DISTANCE MATRIX RESPONSE ELEMENT STATUS" exception.
     */
    public function invalidDistanceMatrixResponseElementStatus()
    {
        return (sprintf(
            'The distance matrix response element status can only be : %s.',
            implode(', ', DistanceMatrixElementStatus::getDistanceMatrixElementStatus())
        ));
    }
}
