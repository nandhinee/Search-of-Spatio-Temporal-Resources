<?php

/*
 * This file is part of the Ivory Google Map package.
 *
 * (c) Eric GELOEN <geloen.eric@gmail.com>
 *
 * For the full copyright and license information, please read the LICENSE
 * file that was distributed with this source code.
 */

//namespace Ivory\GoogleMap\Exception;

/*include_once 'src2\Controls\ControlPosition;
include_once 'src2\Controls\MapTypeControlStyle;
include_once 'src2\Controls\ScaleControlStyle;
include_once 'src2\Controls\ZoomControlStyle;
include_once 'src2\Overlays\Animation;
include_once 'src2\MapTypeId;*/

include_once 'src2\Controls\ControlPosition.php';
include_once 'src2\Controls\MapTypeControlStyle.php';
include_once 'src2\Controls\ScaleControlStyle.php';
include_once 'src2\Controls\ZoomControlStyle.php';
include_once 'src2\Overlays\Animation.php';
include_once 'src2\MapTypeId.php';

/**
 * Helper exception.
 *
 * @author GeLo <geloen.eric@gmail.com>
 */
class HelperException extends Exception
{
    /**
     * Gets the "INVALID ANIMATION" exception.
     *
     * @return \Ivory\GoogleMap\Exception\HelperException The "INVALID ANIMATION" exception.
     */
    public static function invalidAnimation()
    {
        return new static(sprintf('The animation can only be : %s.', implode(', ', Animation::getAnimations())));
    }

    /**
     * Gets the "INVALID AUTOCOMPLETE BOUND" exception.
     *
     * @return \Ivory\GoogleMap\Exception\TemplatingException The "INVALID AUTOCOMPLETE BOUND" exception.
     */
    public static function invalidAutocompleteBound()
    {
        return new static('The place autocomplete bound must have coordinates.');
    }

    /**
     * Gets the "INVALID CONTROL POSITION" exception.
     *
     * @return \Ivory\GoogleMap\Exception\HelperException The "INVALID CONTROL POSITION" exception.
     */
    public static function invalidControlPosition()
    {
        return new static(sprintf(
            'The control position can only be : %s.',
            implode(', ', ControlPosition::getControlPositions())
        ));
    }

    /**
     * Gets the "INVALID ENCODED PATH" exception.
     *
     * @return \Ivory\GoogleMap\Exception\HelperException The "INVALID ENCODED PATH" exception.
     */
    public static function invalidEncodedPath()
    {
        return new static('The encoded path must be a string value.');
    }

    /**
     * Gets the "INVALID EXTENSION" exception.
     *
     * @param string $name The "INVALID EXTENSION" exception.
     *
     * @return \Ivory\GoogleMap\Exception\HelperException The "INVALID EXTENSION" exception.
     */
    public static function invalidExtension($name)
    {
        return new static(sprintf('The extension helper "%s" does not exist.', $name));
    }

    /**
     * Gets the "INVALID MAP TYPE CONTROL STYLE" exception.
     *
     * @return \Ivory\GoogleMap\Exception\HelperException The "INVALID MAP TYPE CONTROL STYLE" exception.
     */
    public static function invalidMapTypeControlStyle()
    {
        return new static(sprintf(
            'The map type control style can only be : %s.',
            implode(', ', MapTypeControlStyle::getMapTypeControlStyles())
        ));
    }

    /**
     * Gets the "INVALID MAP TYPE ID" exception.
     *
     * @return \Ivory\GoogleMap\Exception\HelperException The "INVALID MAP TYPE ID" exception.
     */
    public static function invalidMapTypeId()
    {
        return new static(sprintf('The map type id can only be : %s.', implode(', ', MapTypeId::getMapTypeIds())));
    }

    /**
     * Gets the "INVALID MARKER CLUSTER HELPER" exception.
     *
     * @return \Ivory\GoogleMap\Exception\HelperException The "INVALID MARKER CLUSTER HELPER" exception.
     */
    public static function invalidMarkerClusterHelper()
    {
        return new static('The marker cluster helper can not be resolved.');
    }

    /**
     * Gets the "INVALID SCALE CONTROL STYLE" exception.
     *
     * @return \Ivory\GoogleMap\Exception\HelperException The "INVALID SCALE CONTROL STYLE" exception.
     */
    public static function invalidScaleControlStyle()
    {
        return new static(sprintf(
            'The scale control style can only be : %s.',
            implode(', ', ScaleControlStyle::getScaleControlStyles())
        ));
    }

    /**
     * Gets the "INVALID ZOOM CONTROL STYLE" exception.
     *
     * @return \Ivory\GoogleMap\Exception\HelperException The "INVALID ZOOM CONTROL STYLE" exception.
     */
    public static function invalidZoomControlStyle()
    {
        return new static(sprintf(
            'The zoom control style can only be : %s.',
            implode(', ', ZoomControlStyle::getZoomControlStyles())
        ));
    }
}
