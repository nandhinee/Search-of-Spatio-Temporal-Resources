PropertyAccess Component
========================

PropertyAccess reads/writes values from/to object/array graphs using a simple
string notation.

Resources
---------

You can run the unit tests with the following command:

    $ cd path/to/Symfony/Component/PropertyAccess/
    $ composer install
    $ phpunit
